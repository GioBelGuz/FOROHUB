package com.aluraCursos.ForoHub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForoHubApplicationTests {

	@Test
	void contextLoads() {
	}

}
