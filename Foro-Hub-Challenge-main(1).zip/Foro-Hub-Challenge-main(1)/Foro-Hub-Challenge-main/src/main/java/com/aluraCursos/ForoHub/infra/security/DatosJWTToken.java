package com.aluraCursos.ForoHub.infra.security;

public record DatosJWTToken(String jwTtoken) {
}
